docker run -it --rm -p 8888:8080 -v `pwd`:/usr/local/structurizr structurizr/lite
