# Theme Testing

The `.puml` files in this folder are copied from various PlantUML examples to test the color styling/theme embedded in `AWSCommon.puml`, including support for "dark mode" via `!$AWS_DARK = true`.
